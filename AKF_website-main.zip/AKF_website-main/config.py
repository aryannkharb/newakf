# config.py — Email credentials
# Use a Gmail App Password (NOT your normal Gmail password)
# Steps: Google Account → Security → 2-Step Verification ON → App Passwords → Generate one
EMAIL_SENDER = "foundationtheak@gmail.com"
EMAIL_PASSWORD = "your_app_password_here"   # <-- replace this
