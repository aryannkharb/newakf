"""
add_user.py — Add members to the AKF login system
Usage: python add_user.py
"""
import pandas as pd
from werkzeug.security import generate_password_hash
import os

USERS_FILE = 'users.csv'

def load():
    if not os.path.exists(USERS_FILE):
        pd.DataFrame(columns=['username','password_hash','name','role','email','role_level']
                     ).to_csv(USERS_FILE, index=False)
    return pd.read_csv(USERS_FILE)

def add_user(username, password, name, role, email, role_level):
    df = load()
    if username in df['username'].values:
        print(f"  ✗ User '{username}' already exists.")
        return
    new = pd.DataFrame([{
        'username':      username,
        'password_hash': generate_password_hash(password),
        'name':          name,
        'role':          role,
        'email':         email,
        'role_level':    role_level   # 'board' or 'member'
    }])
    pd.concat([df, new], ignore_index=True).to_csv(USERS_FILE, index=False)
    print(f"  ✓ {name} ({role_level}) added successfully.")

if __name__ == '__main__':
    print("=== AKF — Add Member ===\n")
    uname      = input("Username       : ").strip()
    pwd        = input("Password       : ").strip()
    name       = input("Full Name      : ").strip()
    role       = input("Role/Title     : ").strip()
    email      = input("Email Address  : ").strip()
    print("Role Level     : board / member")
    role_level = input("Role Level     : ").strip().lower()
    if role_level not in ('board', 'member'):
        print("  ✗ role_level must be 'board' or 'member'")
    else:
        add_user(uname, pwd, name, role, email, role_level)
