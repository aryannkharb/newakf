"""
app.py — AKF Full Backend
Run: pip install flask pandas werkzeug
Then: python app.py  →  http://127.0.0.1:5000
"""
from flask import Flask, request, session, jsonify, redirect, url_for, send_from_directory
import pandas as pd
import json, os, smtplib, ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

try:
    from config import EMAIL_SENDER, EMAIL_PASSWORD
    EMAIL_ENABLED = True
except ImportError:
    EMAIL_ENABLED = False
    EMAIL_SENDER = EMAIL_PASSWORD = ""

app = Flask(__name__, static_folder='.', static_url_path='')
app.secret_key = os.environ.get('AKF_SECRET', 'akf-dev-secret-2025')

USERS_FILE        = 'users.csv'
ANNOUNCEMENTS_FILE = 'announcements.csv'
FUND_FILE         = 'fund_stats.json'

# ── Data helpers ──────────────────────────────────────────────────────────────
def load_users():
    if not os.path.exists(USERS_FILE):
        pd.DataFrame(columns=['username','password_hash','name','role','email','role_level']
                     ).to_csv(USERS_FILE, index=False)
    return pd.read_csv(USERS_FILE)

def load_announcements():
    if not os.path.exists(ANNOUNCEMENTS_FILE):
        pd.DataFrame(columns=['id','title','content','posted_by','posted_at','is_active']
                     ).to_csv(ANNOUNCEMENTS_FILE, index=False)
    return pd.read_csv(ANNOUNCEMENTS_FILE)

def load_fund():
    if not os.path.exists(FUND_FILE):
        data = {"amount": 50000, "updated_by": "System", "updated_at": str(datetime.now())}
        with open(FUND_FILE, 'w') as f:
            json.dump(data, f)
    with open(FUND_FILE) as f:
        return json.load(f)

def save_fund(data):
    with open(FUND_FILE, 'w') as f:
        json.dump(data, f, indent=2)

# ── Email ─────────────────────────────────────────────────────────────────────
def get_all_emails():
    users = load_users()
    return users['email'].dropna().tolist()

def send_email_to_all(subject, html_body):
    if not EMAIL_ENABLED:
        print("[EMAIL DISABLED] Would have sent:", subject)
        return
    emails = get_all_emails()
    if not emails:
        return
    ctx = ssl.create_default_context()
    try:
        with smtplib.SMTP_SSL('smtp.gmail.com', 465, context=ctx) as server:
            server.login(EMAIL_SENDER, EMAIL_PASSWORD)
            for addr in emails:
                msg = MIMEMultipart('alternative')
                msg['Subject'] = f"[AKF] {subject}"
                msg['From']    = EMAIL_SENDER
                msg['To']      = addr
                msg.attach(MIMEText(html_body, 'html'))
                server.sendmail(EMAIL_SENDER, addr, msg.as_string())
    except Exception as e:
        print(f"[EMAIL ERROR] {e}")

# ── Auth helpers ──────────────────────────────────────────────────────────────
def current_user():
    return session.get('user')

def is_board():
    return session.get('role_level') == 'board'

def login_required(f):
    from functools import wraps
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not current_user():
            return redirect('/login')
        return f(*args, **kwargs)
    return wrapper

def board_required(f):
    from functools import wraps
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not current_user():
            return jsonify({'error': 'Not logged in'}), 401
        if not is_board():
            return jsonify({'error': 'Board access only'}), 403
        return f(*args, **kwargs)
    return wrapper

# ── Static Pages ──────────────────────────────────────────────────────────────
@app.route('/')
def index():        return send_from_directory('.', 'index.html')

@app.route('/about')
def about():        return send_from_directory('.', 'about.html')

@app.route('/programs')
def programs():     return send_from_directory('.', 'programs.html')

@app.route('/donate')
def donate():       return send_from_directory('.', 'donate.html')

@app.route('/contact')
def contact():      return send_from_directory('.', 'contact.html')

@app.route('/login', methods=['GET'])
def login_page():   return send_from_directory('.', 'login.html')

# ── Auth ──────────────────────────────────────────────────────────────────────
@app.route('/login', methods=['POST'])
def login_api():
    d = request.get_json(force=True)
    users = load_users()
    match = users[users['username'] == d.get('username','').strip()]
    if match.empty or not check_password_hash(match.iloc[0]['password_hash'], d.get('password','')):
        return jsonify({'success': False, 'message': 'Invalid username or password.'})
    u = match.iloc[0]
    session['user']       = u['username']
    session['name']       = u['name']
    session['role']       = u['role']
    session['role_level'] = u['role_level']
    return jsonify({'success': True, 'name': u['name'], 'role_level': u['role_level']})

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

@app.route('/dashboard')
@login_required
def dashboard():    return send_from_directory('.', 'dashboard.html')

@app.route('/api/me')
@login_required
def me():
    return jsonify({
        'username':   session['user'],
        'name':       session['name'],
        'role':       session['role'],
        'role_level': session['role_level']
    })

# ── Announcements ─────────────────────────────────────────────────────────────
@app.route('/api/announcements')
def get_announcements():
    df = load_announcements()
    if df.empty:
        return jsonify([])
    active = df[df['is_active'] == True].sort_values('posted_at', ascending=False)
    return jsonify(active.head(10).to_dict('records'))

@app.route('/api/announcement', methods=['POST'])
@board_required
def post_announcement():
    d = request.get_json(force=True)
    title   = d.get('title','').strip()
    content = d.get('content','').strip()
    if not title or not content:
        return jsonify({'error': 'Title and content required'}), 400

    df = load_announcements()
    new_id = int(df['id'].max() + 1) if not df.empty and not df['id'].isna().all() else 1
    new_row = pd.DataFrame([{
        'id': new_id, 'title': title, 'content': content,
        'posted_by': session['name'],
        'posted_at': datetime.now().strftime('%Y-%m-%d %H:%M'),
        'is_active': True
    }])
    pd.concat([df, new_row], ignore_index=True).to_csv(ANNOUNCEMENTS_FILE, index=False)

    send_email_to_all(
        f"New Announcement: {title}",
        f"<h2>{title}</h2><p>{content}</p><p><em>Posted by {session['name']}</em></p>"
    )
    return jsonify({'success': True})

@app.route('/api/announcement/<int:ann_id>', methods=['DELETE'])
@board_required
def delete_announcement(ann_id):
    df = load_announcements()
    df.loc[df['id'] == ann_id, 'is_active'] = False
    df.to_csv(ANNOUNCEMENTS_FILE, index=False)
    return jsonify({'success': True})

# ── Fund Stats ────────────────────────────────────────────────────────────────
@app.route('/api/fund')
def get_fund():
    return jsonify(load_fund())

@app.route('/api/fund', methods=['POST'])
@board_required
def update_fund():
    d = request.get_json(force=True)
    try:
        amount = int(d.get('amount', 0))
    except:
        return jsonify({'error': 'Invalid amount'}), 400

    data = {'amount': amount, 'updated_by': session['name'],
            'updated_at': datetime.now().strftime('%Y-%m-%d %H:%M')}
    save_fund(data)

    send_email_to_all(
        "Fund Amount Updated",
        f"<p>The AKF fund counter has been updated to <strong>₹{amount:,}</strong> by {session['name']}.</p>"
    )
    return jsonify({'success': True})

# ── Contact Form ──────────────────────────────────────────────────────────────
@app.route('/api/contact', methods=['POST'])
def contact_form():
    d = request.get_json(force=True)
    name    = d.get('name','')
    email   = d.get('email','')
    subject = d.get('subject','')
    message = d.get('message','')
    send_email_to_all(
        f"Contact Form: {subject}",
        f"<p><b>From:</b> {name} ({email})</p><p><b>Message:</b> {message}</p>"
    )
    return jsonify({'success': True})

# ── Member Directory (board only) ─────────────────────────────────────────────
@app.route('/api/members')
@board_required
def members():
    users = load_users()
    safe = users[['name','role','email','role_level']].to_dict('records')
    return jsonify(safe)

if __name__ == '__main__':
    print("\n  AKF Portal → http://127.0.0.1:5000\n")
    app.run(debug=True)
